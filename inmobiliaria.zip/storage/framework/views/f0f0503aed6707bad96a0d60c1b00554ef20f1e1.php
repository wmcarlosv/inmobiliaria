<?php $__env->startSection('title', 'Consultants'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Consultants</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
    	<div class="panel-heading">
    		<h2>All Consultants</h2>
    	</div>
    	<div class="panel-body">
    		<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    		<a href="<?php echo e(route('consultants.create')); ?>" class="btn btn-success"><i class="fa fa-plus"></i> New Consultant</a>
    		<br />
    		<br />
    		<table class="table table-bordered table-striped data-table">
    			<thead>
    				<th>ID</th>
    				<th>Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Direction</th>
                    <th>Avatar</th>
    				<th>Actions</th>
    			</thead>
    			<tbody>
    				<?php $__currentLoopData = $consultants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    				<tr>
    					<td><?php echo e($consultant->id); ?></td>
    					<td><?php echo e($consultant->name); ?></td>
                        <td><?php echo e($consultant->phone); ?></td>
                        <td><?php echo e($consultant->email); ?></td>
                        <td><?php echo e($consultant->direction); ?></td>
                        <td>
                            <?php if( isset($consultant->avatar) and !empty($consultant->avatar) ): ?>
                                <img src="<?php echo e(asset('storage/avatars')); ?>/<?php echo e($consultant->avatar); ?>" width="80" height="100" class="img-thumbnail">
                            <?php else: ?>
                                <img src="<?php echo e(asset('storage/avatars')); ?>/empty.jpg" width="80" height="100" class="img-thumbnail">
                            <?php endif; ?>

                        </td>
    					<td>
    						<a href="<?php echo e(route('consultants.edit',['id' => $consultant->id])); ?>" class="btn btn-info"><i class="fa fa-pencil"></i> Update</a>
    						<?php echo Form::open(['method' => 'DELETE', 'style' => 'display:inline;','route' => ['consultants.destroy', $consultant->id]],null,null,['style' => 'display:inline;']); ?>

    							<?php echo Form::button('<i class="fa fa-times"></i> Delete', ['type' => 'sumit', 'class' => 'btn btn-danger delete-record']); ?>

    						<?php echo Form::close(); ?>

    					</td>
    				</tr>
    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			</tbody>
    		</table>
    	</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>