<?php $__env->startSection('title', 'Actualizar Caracteristica'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Caracteristicas</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    	<div class="panel-heading">
    		<h2>Actualizar Caracteristica</h2>
    	</div>
    	<div class="panel-body">
    		<?php echo Form::open(['method' => 'PUT', 'route' => ['features.update', $feature->id]]); ?>

            <div class="form-group">
                <?php echo Form::label('name', 'Name: '); ?>

                <?php echo Form::text('name',$feature->name,['id' => 'name', 'class' => 'form-control']); ?>

            </div>
            <?php echo Form::button('<i class="fa fa-floppy-o"></i> Guardar', ['type' => 'submit', 'class' => 'btn btn-success']); ?>

            <a href="<?php echo e(route('features.index')); ?>" class="btn btn-danger"><i class="fa fa-times"></i> Cancelar</a>
            <?php echo Form::close(); ?>

    	</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>