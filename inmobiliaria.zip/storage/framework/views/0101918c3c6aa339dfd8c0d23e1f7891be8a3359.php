
<?php echo $__env->make('adminlte::passwords.email', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>