<?php $__env->startSection('title', 'Property Types'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Property Types</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
    	<div class="panel-heading">
    		<h2>All Property Types</h2>
    	</div>
    	<div class="panel-body">
    		<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    		<a href="<?php echo e(route('property-types.create')); ?>" class="btn btn-success"><i class="fa fa-plus"></i> New Property Type</a>
    		<br />
    		<br />
    		<table class="table table-bordered table-striped data-table">
    			<thead>
    				<th>ID</th>
    				<th>Name</th>
    				<th>Actions</th>
    			</thead>
    			<tbody>
    				<?php $__currentLoopData = $propertytypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propertytype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    				<tr>
    					<td><?php echo e($propertytype->id); ?></td>
    					<td><?php echo e($propertytype->name); ?></td>
    					<td>
    						<a href="<?php echo e(route('property-types.edit',['id' => $propertytype->id])); ?>" class="btn btn-info"><i class="fa fa-pencil"></i> Update</a>
    						<?php echo Form::open(['method' => 'DELETE', 'style' => 'display:inline;','route' => ['property-types.destroy', $propertytype->id]],null,null,['style' => 'display:inline;']); ?>

    							<?php echo Form::button('<i class="fa fa-times"></i> Delete', ['type' => 'sumit', 'class' => 'btn btn-danger delete-record']); ?>

    						<?php echo Form::close(); ?>

    					</td>
    				</tr>
    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			</tbody>
    		</table>
    	</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>