<?php $__env->startSection('title', 'New Consultant'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Consultants</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    	<div class="panel-heading">
    		<h2>New Consultant</h2>
    	</div>
    	<div class="panel-body">
    		<?php echo Form::open(['route' => 'consultants.store', 'files' => true]); ?>

            <div class="form-group">
                <?php echo Form::label('name', 'Name: '); ?>

                <?php echo Form::text('name',null,['id' => 'name', 'class' => 'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('phone', 'Phone: '); ?>

                <?php echo Form::text('phone',null,['id' => 'phone', 'class' => 'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('email', 'Email: '); ?>

                <?php echo Form::text('email',null,['id' => 'email', 'class' => 'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('direction', 'Direction: '); ?>

                <?php echo Form::text('direction',null,['id' => 'direction', 'class' => 'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('avatar', 'Avatar: '); ?>

                <?php echo Form::file('avatar',['id' => 'avatar', 'class' => 'form-control']); ?>

            </div>
            <?php echo Form::button('<i class="fa fa-floppy-o"></i> Save', ['type' => 'submit', 'class' => 'btn btn-success']); ?>

            <a href="<?php echo e(route('consultants.index')); ?>" class="btn btn-danger"><i class="fa fa-times"></i> Cancel</a>
            <?php echo Form::close(); ?>

    	</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>