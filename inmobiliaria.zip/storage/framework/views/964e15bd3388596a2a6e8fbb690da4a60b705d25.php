<?php $__env->startSection('title', 'Caracteristicas'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Caracteristicas</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
    	<div class="panel-heading">
    		<h2>Todas las Caracteristicas</h2>
    	</div>
    	<div class="panel-body">
    		<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    		<a href="<?php echo e(route('features.create')); ?>" class="btn btn-success"><i class="fa fa-plus"></i> New Feature</a>
    		<br />
    		<br />
    		<table class="table table-bordered table-striped data-table">
    			<thead>
    				<th>ID</th>
    				<th>Nombre</th>
    				<th>Acciones</th>
    			</thead>
    			<tbody>
    				<?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    				<tr>
    					<td><?php echo e($feature->id); ?></td>
    					<td><?php echo e($feature->name); ?></td>
    					<td>
    						<a href="<?php echo e(route('features.edit',['id' => $feature->id])); ?>" class="btn btn-info"><i class="fa fa-pencil"></i> Actualizar</a>
    						<?php echo Form::open(['method' => 'DELETE', 'style' => 'display:inline;','route' => ['features.destroy', $feature->id]],null,null,['style' => 'display:inline;']); ?>

    							<?php echo Form::button('<i class="fa fa-times"></i> Eliminar', ['type' => 'sumit', 'class' => 'btn btn-danger delete-record']); ?>

    						<?php echo Form::close(); ?>

    					</td>
    				</tr>
    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			</tbody>
    		</table>
    	</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>